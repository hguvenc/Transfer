This directory contains the documentation of Togl, the Tk OpenGL widget.
The documentation also doubles as the contents of the Togl home page.
